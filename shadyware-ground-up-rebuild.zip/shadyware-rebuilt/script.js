'use strict';
// Curated directory data. Replace or extend these entries as releases are approved.
const scripts = [
 {id:'prison-life',name:'Prison Life',game:'Prison Life',description:'A dedicated listing for the Prison Life community. Check Discord for the current release and compatibility notes.',status:'UPDATED',tags:['pc','mobile','keyless','updated'],version:'Listing updated 25 Nov 2026',access:'Check Discord for current access details.'},
 {id:'universal-toolkit',name:'Universal Toolkit',game:'Universal',description:'A general-purpose utility listing. Supported experiences and features are announced with each release.',status:'NEW',tags:['pc','key-system','new'],version:'New listing',access:'Access details are provided in Discord.'},
 {id:'mobile-essentials',name:'Mobile Essentials',game:'Universal',description:'A mobile-focused listing with touch-device compatibility notes and release updates.',status:'NEW',tags:['mobile','keyless','new'],version:'New listing',access:'Access details are provided in Discord.'},
 {id:'pc-utility',name:'PC Utility',game:'Universal',description:'A desktop-focused utility listing. Review the current compatibility notes before using.',status:'UPDATED',tags:['pc','key-system','updated'],version:'Listing updated 25 Nov 2026',access:'Access details are provided in Discord.'},
 {id:'community-release',name:'Community Release',game:'Community',description:'Community release slot for featured tools and limited-time announcements.',status:'NEW',tags:['pc','mobile','keyless','new'],version:'New listing',access:'Check Discord for availability.'},
 {id:'legacy-collection',name:'Legacy Collection',game:'Various',description:'An archive slot for older releases. These may no longer be maintained or compatible.',status:'ARCHIVE',tags:['pc','key-system'],version:'Archived listing',access:'Availability is not guaranteed.'}
];
const $ = (s,root=document)=>root.querySelector(s);
const grid=$('#scriptGrid'), search=$('#searchInput'), result=$('#resultCount'), empty=$('#emptyState'), dialog=$('#scriptDialog');
let activeFilter='all';
const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function render(){
 const q=search.value.trim().toLowerCase().split(/\s+/).filter(Boolean);
 const found=scripts.filter(item=>{
  const hay=[item.name,item.game,item.description,item.status,item.version,item.access,...item.tags].join(' ').toLowerCase();
  return (activeFilter==='all'||item.tags.includes(activeFilter))&&q.every(word=>hay.includes(word));
 });
 grid.innerHTML=found.map(item=>`<article class="script-card" tabindex="0" role="button" data-id="${esc(item.id)}" aria-label="View ${esc(item.name)} details"><div class="card-top"><span class="card-icon">${item.name==='Prison Life'?'PL':item.name==='Universal Toolkit'?'UT':item.name==='Mobile Essentials'?'M':'S.'}</span><span class="status ${item.status==='NEW'?'new':''}">${esc(item.status)}</span></div><h3>${esc(item.name)}</h3><p>${esc(item.description)}</p><div class="card-tags">${item.tags.slice(0,3).map(t=>`<span class="tag">${esc(t.replace('-',' ').toUpperCase())}</span>`).join('')}</div><span class="card-open">↗</span></article>`).join('');
 result.textContent=`SHOWING ${String(found.length).padStart(2,'0')} SCRIPTS`;
 $('#allCount').textContent=String(scripts.length).padStart(2,'0');empty.hidden=found.length!==0;
}
function showDetails(id){const item=scripts.find(x=>x.id===id);if(!item)return;$('#dialogTags').textContent=item.tags.map(t=>t.toUpperCase()).join(' / ');$('#dialogTitle').textContent=item.name;$('#dialogDescription').textContent=item.description;$('#dialogMeta').textContent=`${item.game.toUpperCase()}  •  ${item.version.toUpperCase()}  •  ${item.access.toUpperCase()}`;dialog.showModal();}
grid.addEventListener('click',e=>{const card=e.target.closest('[data-id]');if(card)showDetails(card.dataset.id)});
grid.addEventListener('keydown',e=>{if((e.key==='Enter'||e.key===' ')&&e.target.matches('[data-id]')){e.preventDefault();showDetails(e.target.dataset.id)}});
search.addEventListener('input',render);
$('#filters').addEventListener('click',e=>{const btn=e.target.closest('[data-filter]');if(!btn)return;activeFilter=btn.dataset.filter;document.querySelectorAll('.filter').forEach(b=>b.classList.toggle('active',b===btn));render()});
$('#clearFilters').addEventListener('click',()=>{search.value='';activeFilter='all';document.querySelectorAll('.filter').forEach(b=>b.classList.toggle('active',b.dataset.filter==='all'));render()});
$('#dialogClose').addEventListener('click',()=>dialog.close());dialog.addEventListener('click',e=>{if(e.target===dialog)dialog.close()});
const menu=$('#menuToggle'),nav=$('#navlinks');menu.addEventListener('click',()=>{const open=nav.classList.toggle('open');menu.setAttribute('aria-expanded',String(open))});nav.addEventListener('click',e=>{if(e.target.closest('a')){nav.classList.remove('open');menu.setAttribute('aria-expanded','false')}});
document.addEventListener('keydown',e=>{if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='k'){e.preventDefault();search.focus()}});
render();
