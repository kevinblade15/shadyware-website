'use strict';
// Curated directory data. Replace or extend these entries as releases are approved.
const scripts = [
 {id:'prison-life',name:'Prison Life',game:'Prison Life',description:'A dedicated listing for the Prison Life community. Check Discord for the current release and compatibility notes.',status:'UPDATED',tags:['pc','mobile','keyless','updated'],version:'Listing updated 25 Nov 2026',access:'Check Discord for current access details.'},
 {id:'universal-toolkit',name:'Universal Toolkit',game:'Universal',description:'A general-purpose utility listing. Supported experiences and features are announced with each release.',status:'NEW',tags:['pc','key-system','new'],version:'New listing',access:'Access details are provided in Discord.'},
 {id:'mobile-essentials',name:'Mobile Essentials',game:'Universal',description:'A mobile-focused listing with touch-device compatibility notes and release updates.',status:'NEW',tags:['mobile','keyless','new'],version:'New listing',access:'Access details are provided in Discord.'},
 {id:'pc-utility',name:'PC Utility',game:'Universal',description:'A desktop-focused utility listing. Review the current compatibility notes before using.',status:'UPDATED',tags:['pc','key-system','updated'],version:'Listing updated 25 Nov 2026',access:'Access details are provided in Discord.'},
 {id:'community-release',name:'Community Release',game:'Community',description:'Community release slot for featured tools and limited-time announcements.',status:'NEW',tags:['pc','mobile','keyless','new'],version:'New listing',access:'Check Discord for availability.'},
 {id:'legacy-collection',name:'Legacy Collection',game:'Various',description:'An archive slot for older releases. These may no longer be maintained or compatible.',status:'ARCHIVE',tags:['pc','key-system'],version:'Archived listing',access:'Availability is not guaranteed.'}
];
const $ = (s,root=document)=>root.querySelector(s);
const grid=$('#scriptGrid'), search=$('#searchInput'), result=$('#resultCount'), empty=$('#emptyState'), dialog=$('#scriptDialog');
let activeFilter='all';
const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function render(){
 const q=search.value.trim().toLowerCase().split(/\s+/).filter(Boolean);
 const found=scripts.filter(item=>{
  const hay=[item.name,item.game,item.description,item.status,item.version,item.access,...item.tags].join(' ').toLowerCase();
  return (activeFilter==='all'||item.tags.includes(activeFilter))&&q.every(word=>hay.includes(word));
 });
 grid.innerHTML=found.map(item=>`<article class="script-card" tabindex="0" role="button" data-id="${esc(item.id)}" aria-label="View ${esc(item.name)} details"><div class="card-top"><span class="card-icon">${item.name==='Prison Life'?'PL':item.name==='Universal Toolkit'?'UT':item.name==='Mobile Essentials'?'M':'S.'}</span><span class="status ${item.status==='NEW'?'new':''}">${esc(item.status)}</span></div><h3>${esc(item.name)}</h3><p>${esc(item.description)}</p><div class="card-tags">${item.tags.slice(0,3).map(t=>`<span class="tag">${esc(t.replace('-',' ').toUpperCase())}</span>`).join('')}</div><span class="card-open">↗</span></article>`).join('');
 result.textContent=`SHOWING ${String(found.length).padStart(2,'0')} SCRIPTS`;
 $('#allCount').textContent=String(scripts.length).padStart(2,'0');empty.hidden=found.length!==0;
}
function showDetails(id){const item=scripts.find(x=>x.id===id);if(!item)return;$('#dialogTags').textContent=item.tags.map(t=>t.toUpperCase()).join(' / ');$('#dialogTitle').textContent=item.name;$('#dialogDescription').textContent=item.description;$('#dialogMeta').textContent=`${item.game.toUpperCase()}  •  ${item.version.toUpperCase()}  •  ${item.access.toUpperCase()}`;dialog.showModal();}
grid.addEventListener('click',e=>{const card=e.target.closest('[data-id]');if(card)showDetails(card.dataset.id)});
grid.addEventListener('keydown',e=>{if((e.key==='Enter'||e.key===' ')&&e.target.matches('[data-id]')){e.preventDefault();showDetails(e.target.dataset.id)}});
search.addEventListener('input',render);
$('#filters').addEventListener('click',e=>{const btn=e.target.closest('[data-filter]');if(!btn)return;activeFilter=btn.dataset.filter;document.querySelectorAll('.filter').forEach(b=>b.classList.toggle('active',b===btn));render()});
$('#clearFilters').addEventListener('click',()=>{search.value='';activeFilter='all';document.querySelectorAll('.filter').forEach(b=>b.classList.toggle('active',b.dataset.filter==='all'));render()});
$('#dialogClose').addEventListener('click',()=>dialog.close());dialog.addEventListener('click',e=>{if(e.target===dialog)dialog.close()});
const menu=$('#menuToggle'),nav=$('#navlinks');menu.addEventListener('click',()=>{const open=nav.classList.toggle('open');menu.setAttribute('aria-expanded',String(open))});nav.addEventListener('click',e=>{if(e.target.closest('a')){nav.classList.remove('open');menu.setAttribute('aria-expanded','false')}});
document.addEventListener('keydown',e=>{if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='k'){e.preventDefault();search.focus()}});
render();


// Interactive rain field: pointer movement creates small water ripples.
(()=>{
 const canvas=document.getElementById('rainCanvas'); if(!canvas)return;
 const ctx=canvas.getContext('2d'); let w=0,h=0,dpr=1,drops=[],ripples=[],pointer={x:-1000,y:-1000};
 const reduced=window.matchMedia('(prefers-reduced-motion: reduce)').matches;
 function resize(){dpr=Math.min(window.devicePixelRatio||1,1.6);w=innerWidth;h=innerHeight;canvas.width=Math.round(w*dpr);canvas.height=Math.round(h*dpr);canvas.style.width=w+'px';canvas.style.height=h+'px';ctx.setTransform(dpr,0,0,dpr,0,0);drops=Array.from({length:Math.min(110,Math.floor(w/11))},()=>({x:Math.random()*w,y:Math.random()*h,len:8+Math.random()*20,speed:2+Math.random()*5,alpha:.08+Math.random()*.2}));}
 function move(e){pointer.x=e.clientX;pointer.y=e.clientY;if(!reduced&&Math.random()>.68)ripples.push({x:pointer.x,y:pointer.y,r:1,a:.22});}
 addEventListener('resize',resize,{passive:true});addEventListener('pointermove',move,{passive:true});resize();
 function frame(){ctx.clearRect(0,0,w,h);if(!reduced){for(const d of drops){ctx.beginPath();ctx.strokeStyle=`rgba(190,204,220,${d.alpha})`;ctx.lineWidth=.7;ctx.moveTo(d.x,d.y);ctx.lineTo(d.x-2,d.y+d.len);ctx.stroke();d.y+=d.speed;d.x-=.35;if(d.y>h+20){d.y=-30;d.x=Math.random()*w;}}
 for(let i=ripples.length-1;i>=0;i--){const r=ripples[i];ctx.beginPath();ctx.strokeStyle=`rgba(210,220,232,${r.a})`;ctx.lineWidth=1;ctx.arc(r.x,r.y,r.r,0,Math.PI*2);ctx.stroke();r.r+=1.4;r.a*=.965;if(r.a<.015)ripples.splice(i,1);}}
 requestAnimationFrame(frame);}frame();
})();
// Magnetic custom cursor and subtle 3D tilt on showcase cards (desktop only).
(()=>{const cursor=document.querySelector('.custom-cursor'),glow=document.querySelector('.cursor-glow');if(!cursor||matchMedia('(pointer:coarse)').matches)return;
 let x=-100,y=-100;addEventListener('pointermove',e=>{x=e.clientX;y=e.clientY;cursor.style.left=x+'px';cursor.style.top=y+'px';if(glow){glow.style.left=x+'px';glow.style.top=y+'px';}},{passive:true});
 document.querySelectorAll('a,button,.tilt-card').forEach(el=>{el.addEventListener('pointerenter',()=>cursor.classList.add('is-hover'));el.addEventListener('pointerleave',()=>cursor.classList.remove('is-hover'));});
 document.querySelectorAll('.tilt-card').forEach(card=>{card.addEventListener('pointermove',e=>{const r=card.getBoundingClientRect(),px=(e.clientX-r.left)/r.width,py=(e.clientY-r.top)/r.height;card.style.transform=`rotateX(${(0.5-py)*7}deg) rotateY(${(px-0.5)*8}deg) translateY(-4px)`;card.style.setProperty('--mx',(px*100)+'%');card.style.setProperty('--my',(py*100)+'%');});card.addEventListener('pointerleave',()=>{card.style.transform='';});});
})();

// Very brief branded intro: never waits for network assets or other scripts.
(()=>{
 const loader=document.getElementById('quickLoader');
 if(!loader)return;
 const dismiss=()=>loader.classList.add('is-gone');
 if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',()=>setTimeout(dismiss,180),{once:true});
 else setTimeout(dismiss,180);
 // Failsafe in case another script throws before the normal dismissal.
 setTimeout(dismiss,900);
})();
