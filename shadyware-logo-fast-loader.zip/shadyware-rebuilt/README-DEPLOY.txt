SHADYWARE WEBSITE — CLEAN REBUILD

CONTENTS
- index.html: single-page website and all sections
- styles.css: responsive charcoal/grey visual system
- script.js: searchable/filterable curated script directory
- _headers: security headers for static hosts that support this convention
- cloudflare-setup.txt: recommended edge protection setup

DEPLOY TO RENDER
1. Extract this ZIP.
2. Upload the CONTENTS of this folder to the ROOT of your GitHub repository.
   index.html must be at the repository root, not inside another nested folder.
3. Commit to the branch configured in Render (normally main).
4. In Render, use a Static Site with publish directory '.' and no build command.
5. Wait for the deployment to finish, then hard-refresh the site.

IMPORTANT SCRIPT LIBRARY NOTE
The directory is a curated front-end catalogue. The included entries are starter listings and do not contain executable script payloads. Update the `scripts` array in script.js with approved names, descriptions, tags, and current release details. The site intentionally sends users to the official Discord for access rather than inventing download URLs.

DDOS / SECURITY
A static front-end cannot stop volumetric DDoS traffic by itself. Put the domain behind Cloudflare (or another reputable edge/CDN/WAF provider), proxy DNS records through it, enable DDoS protection, configure managed WAF rules, enable bot protections where available, and add rate limits for any future API/auth endpoints. Keep the origin protected so attackers cannot bypass the proxy. Render's origin hosting controls are separate from this static site's JavaScript.

The included _headers file provides browser security headers on hosts that honor that convention. Render static hosting may not apply this file automatically; configure equivalent headers in the host dashboard or a supported rewrite/header configuration. These headers are not DDoS mitigation.

VISUAL UPDATE
- Interactive rain canvas with pointer ripple response, desktop custom cursor, and 3D tilt showcase cards. No music button or autoplay audio is included.
- The supplied logo URL (https://ibb.co/sJjhx55r) is an iBB share-page URL, not a direct image file. The header/footer currently retain a styled S. fallback and link to that source. Replace it with the direct i.ibb.co image URL to display the exact uploaded logo.
