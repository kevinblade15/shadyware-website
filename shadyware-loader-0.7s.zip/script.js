/* Loader: 0.7 seconds total, including its fade-out. */
(function initPageLoader(){
  const loader = document.getElementById("loader");
  if (!loader) return;
  let finished = false;
  function finishLoading(){
    if (finished) return;
    finished = true;
    loader.classList.add("done");
    loader.setAttribute("aria-hidden", "true");
  }
  // The script is loaded at the end of body, so the loader already exists.
  // 550ms visible + 150ms fade = 700ms total.
  window.setTimeout(finishLoading, 550);
})();

const DISCORD = "https://discord.gg/GSevFng2Ap";

/* Lightweight animated rain. Respects reduced-motion and scales with screen size. */
(function initRain(){
  const canvas=document.getElementById("rainCanvas");
  if(!canvas || window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
  const ctx=canvas.getContext("2d");
  if(!ctx) return;
  let width=0,height=0,drops=[],raf=0;
  const density=()=>Math.min(110,Math.floor(width/12));
  function resize(){
    const dpr=Math.min(window.devicePixelRatio||1,1.5);
    width=window.innerWidth;height=window.innerHeight;
    canvas.width=Math.floor(width*dpr);canvas.height=Math.floor(height*dpr);
    canvas.style.width=width+"px";canvas.style.height=height+"px";
    ctx.setTransform(dpr,0,0,dpr,0,0);
    const count=density();
    drops=Array.from({length:count},()=>({x:Math.random()*width,y:Math.random()*height,len:8+Math.random()*17,speed:2.2+Math.random()*3.2,alpha:.08+Math.random()*.2}));
  }
  function draw(){
    ctx.clearRect(0,0,width,height);
    ctx.lineWidth=.7;
    for(const d of drops){
      ctx.strokeStyle=`rgba(190,202,214,${d.alpha})`;
      ctx.beginPath();ctx.moveTo(d.x,d.y);ctx.lineTo(d.x-2,d.y+d.len);ctx.stroke();
      d.x-=.35;d.y+=d.speed;
      if(d.y>height+25){d.y=-25;d.x=Math.random()*width;}
      if(d.x<-10)d.x=width+10;
    }
    raf=requestAnimationFrame(draw);
  }
  resize();draw();
  window.addEventListener("resize",resize,{passive:true});
  document.addEventListener("visibilitychange",()=>{if(document.hidden){cancelAnimationFrame(raf);}else{cancelAnimationFrame(raf);draw();}});
})();


/* Replace these sample entries with your real product information. */
const products = [
  {id:"product-one",name:"Product One",category:"available",status:"AVAILABLE",symbol:"◈",description:"Add the official description and features for this release.",version:"v1.0",tags:["Release","Shadyware"]},
  {id:"product-two",name:"Product Two",category:"coming",status:"COMING SOON",symbol:"⌁",description:"A new project is in development. Join Discord for announcements.",version:"In development",tags:["In development"]},
  {id:"product-three",name:"Product Three",category:"coming",status:"COMING SOON",symbol:"⟡",description:"More details are on the way. Follow the changelog for updates.",version:"Planned",tags:["Planned"]}
];
const changes = [
  {version:"1.0.0",date:"NOV 24, 2026",title:"Shadyware website refresh",description:"A redesigned home page, product directory, creator program information, and updated community hub.",tag:"WEBSITE"}
];
const faqs = [
  ["Where can I find product downloads?","Product information and official access details are shared through the Shadyware Discord. Use the links on this website to reach the community."],
  ["How do I get support?","Join the Discord server and open a support ticket in the appropriate channel. Include the product name and a clear description of the issue."],
  ["How do I apply for the Creator Program?","Create one video showcasing a Shadyware product, then submit your application through Discord. Applications are reviewed before acceptance."],
  ["What do accepted creators receive?","Accepted creators receive free premium access, faster ticket responses, and access to special products while they are in the program."],
  ["Where are updates posted?","Version history and website updates appear in the Changelog section. Product announcements are also shared in Discord."]
];

const grid = document.getElementById("productGrid");
const search = document.getElementById("productSearch");
const empty = document.getElementById("emptyState");
let activeFilter = "all";

function renderProducts(){
  const q = search.value.trim().toLowerCase();
  const list = products.filter(p => (activeFilter==="all" || p.category===activeFilter) && (p.name+" "+p.description+" "+p.tags.join(" ")).toLowerCase().includes(q));
  grid.innerHTML = list.map((p) => {
    const index = products.indexOf(p)+1;
    return `<a class="product-card" href="products/${p.id}.html"><div class="product-top"><span class="product-index">0${index} / SHADYWARE</span><span class="status ${p.category}">${p.status}</span></div><div class="product-symbol">${p.symbol}</div><h3>${p.name}</h3><p>${p.description}</p><span class="product-arrow">↗</span><span class="card-more">VIEW PRODUCT</span></a>`;
  }).join("");
  empty.hidden = list.length!==0;
}
function showProduct(p){
  document.getElementById("modalTitle").textContent=p.name;
  document.getElementById("modalDescription").textContent=p.description;
  document.getElementById("modalStatus").textContent=p.status;
  document.getElementById("modalMeta").innerHTML=[p.version,...p.tags].map(x=>`<span>${x}</span>`).join("");
  const action=document.getElementById("modalAction");
  action.href=DISCORD;
  action.textContent=p.category==="available"?"Get access in Discord ↗":"Follow updates in Discord ↗";
  document.getElementById("productModal").classList.add("show");
  document.getElementById("productModal").setAttribute("aria-hidden","false");
}
function closeProduct(){document.getElementById("productModal").classList.remove("show");document.getElementById("productModal").setAttribute("aria-hidden","true");}
document.getElementById("modalClose").addEventListener("click",closeProduct);
document.getElementById("productModal").addEventListener("click",e=>{if(e.target.id==="productModal")closeProduct();});
document.addEventListener("keydown",e=>{if(e.key==="Escape"){closeProduct();document.getElementById("musicPrompt").classList.remove("show");}});
search.addEventListener("input",renderProducts);
document.getElementById("filters").addEventListener("click",e=>{
  const b=e.target.closest("[data-filter]");if(!b)return;
  activeFilter=b.dataset.filter;
  document.querySelectorAll(".filter").forEach(x=>x.classList.toggle("active",x===b));
  renderProducts();
});
document.getElementById("changelogList").innerHTML=changes.map(c=>`<article class="timeline-item reveal"><div><div class="timeline-version">VERSION ${c.version}</div><span class="timeline-date">${c.date}</span></div><div><h3>${c.title}</h3><p>${c.description}</p></div><span class="timeline-tag">${c.tag}</span></article>`).join("");
document.getElementById("faqList").innerHTML=faqs.map(([q,a])=>`<article class="faq-item"><button class="faq-question" aria-expanded="false"><span>${q}</span><span>＋</span></button><div class="faq-answer"><p>${a}</p></div></article>`).join("");
document.getElementById("faqList").addEventListener("click",e=>{
  const button=e.target.closest(".faq-question");if(!button)return;
  const item=button.parentElement,answer=item.querySelector(".faq-answer"),open=item.classList.toggle("open");
  button.setAttribute("aria-expanded",String(open));answer.style.maxHeight=open?answer.scrollHeight+"px":"0px";
});

const revealObserver=new IntersectionObserver(entries=>entries.forEach(entry=>{if(entry.isIntersecting){entry.target.classList.add("visible");revealObserver.unobserve(entry.target);}}),{threshold:.12});
function observeReveals(){document.querySelectorAll(".reveal:not(.visible)").forEach(el=>revealObserver.observe(el));}
renderProducts();observeReveals();
document.getElementById("year").textContent=new Date().getFullYear();

const menu=document.getElementById("menuToggle"),nav=document.getElementById("navLinks");
menu.addEventListener("click",()=>nav.classList.toggle("open"));
nav.querySelectorAll("a").forEach(a=>a.addEventListener("click",()=>nav.classList.remove("open")));
window.addEventListener("scroll",()=>{
  const max=document.documentElement.scrollHeight-innerHeight;
  document.getElementById("scrollProgress").style.width=(max>0?scrollY/max*100:0)+"%";
},{passive:true});

/* Soft synthesized ambient pad: no external audio file or autoplay. */
let audioCtx=null, master=null, oscillators=[], musicOn=false;
function startAmbient(){
  const AudioContext=window.AudioContext||window.webkitAudioContext;
  if(!AudioContext){showToast("Background audio is not supported in this browser.");return;}
  if(!audioCtx){
    audioCtx=new AudioContext();master=audioCtx.createGain();master.gain.value=0;master.connect(audioCtx.destination);
    [110,164.81,220].forEach((freq,i)=>{
      const osc=audioCtx.createOscillator(),gain=audioCtx.createGain(),filter=audioCtx.createBiquadFilter();
      osc.type=i===1?"triangle":"sine";osc.frequency.value=freq;gain.gain.value=[.12,.045,.035][i];filter.type="lowpass";filter.frequency.value=420;
      osc.connect(filter);filter.connect(gain);gain.connect(master);osc.start();oscillators.push(osc);
    });
  }
  audioCtx.resume();master.gain.cancelScheduledValues(audioCtx.currentTime);master.gain.setTargetAtTime(.18,audioCtx.currentTime,.8);musicOn=true;updateSoundButton();
}
function stopAmbient(){
  if(audioCtx&&master){master.gain.cancelScheduledValues(audioCtx.currentTime);master.gain.setTargetAtTime(0,audioCtx.currentTime,.35);}
  musicOn=false;updateSoundButton();
}
function updateSoundButton(){document.getElementById("soundToggle").textContent=musicOn?"♫":"♪";document.getElementById("soundToggle").title=musicOn?"Turn music off":"Turn music on";}
function showToast(msg){const t=document.getElementById("toast");t.textContent=msg;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2200);}
document.getElementById("musicYes").addEventListener("click",()=>{startAmbient();document.getElementById("musicPrompt").classList.remove("show");});
document.getElementById("musicNo").addEventListener("click",()=>{document.getElementById("musicPrompt").classList.remove("show");});
document.getElementById("soundToggle").addEventListener("click",()=>{if(musicOn)stopAmbient();else startAmbient();});
// The loader is handled by initPageLoader at the top of this file.
