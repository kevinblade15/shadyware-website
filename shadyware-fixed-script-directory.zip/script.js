const DISCORD = "https://discord.gg/GSevFng2Ap";

/* Lightweight animated rain. Respects reduced-motion and scales with screen size. */
(function initRain(){
  const canvas=document.getElementById("rainCanvas");
  if(!canvas || window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
  const ctx=canvas.getContext("2d");
  if(!ctx) return;
  let width=0,height=0,drops=[],raf=0;
  const density=()=>Math.min(110,Math.floor(width/12));
  function resize(){
    const dpr=Math.min(window.devicePixelRatio||1,1.5);
    width=window.innerWidth;height=window.innerHeight;
    canvas.width=Math.floor(width*dpr);canvas.height=Math.floor(height*dpr);
    canvas.style.width=width+"px";canvas.style.height=height+"px";
    ctx.setTransform(dpr,0,0,dpr,0,0);
    const count=density();
    drops=Array.from({length:count},()=>({x:Math.random()*width,y:Math.random()*height,len:8+Math.random()*17,speed:2.2+Math.random()*3.2,alpha:.08+Math.random()*.2}));
  }
  function draw(){
    ctx.clearRect(0,0,width,height);
    ctx.lineWidth=.7;
    for(const d of drops){
      ctx.strokeStyle=`rgba(190,202,214,${d.alpha})`;
      ctx.beginPath();ctx.moveTo(d.x,d.y);ctx.lineTo(d.x-2,d.y+d.len);ctx.stroke();
      d.x-=.35;d.y+=d.speed;
      if(d.y>height+25){d.y=-25;d.x=Math.random()*width;}
      if(d.x<-10)d.x=width+10;
    }
    raf=requestAnimationFrame(draw);
  }
  resize();draw();
  window.addEventListener("resize",resize,{passive:true});
  document.addEventListener("visibilitychange",()=>{if(document.hidden){cancelAnimationFrame(raf);}else{cancelAnimationFrame(raf);draw();}});
})();


/* Replace these sample entries with your real product information. */
const products = [
  {id:"product-one",name:"Product One",category:"available",status:"AVAILABLE",symbol:"◈",description:"Add the official description and features for this release.",version:"v1.0",tags:["Release","Shadyware"]},
  {id:"product-two",name:"Product Two",category:"coming",status:"COMING SOON",symbol:"⌁",description:"A new project is in development. Join Discord for announcements.",version:"In development",tags:["In development"]},
  {id:"product-three",name:"Product Three",category:"coming",status:"COMING SOON",symbol:"⟡",description:"More details are on the way. Follow the changelog for updates.",version:"Planned",tags:["Planned"]}
];
const changes = [
  {version:"1.0.0",date:"NOV 24, 2026",title:"Shadyware website refresh",description:"A redesigned home page, product directory, creator program information, and updated community hub.",tag:"WEBSITE"}
];
const faqs = [
  ["Where can I find product downloads?","Product information and official access details are shared through the Shadyware Discord. Use the links on this website to reach the community."],
  ["How do I get support?","Join the Discord server and open a support ticket in the appropriate channel. Include the product name and a clear description of the issue."],
  ["How do I apply for the Creator Program?","Create one video showcasing a Shadyware product, then submit your application through Discord. Applications are reviewed before acceptance."],
  ["What do accepted creators receive?","Accepted creators receive free premium access, faster ticket responses, and access to special products while they are in the program."],
  ["Where are updates posted?","Version history and website updates appear in the Changelog section. Product announcements are also shared in Discord."]
];

/* Script directory: add/edit entries here. Search matches names, games, descriptions and tags. */
const scriptCatalog = [
 {id:"mobile-ui-kit",name:"Mobile UI Kit",game:"Universal",description:"A responsive interface starter designed around touch controls and smaller screens.",tags:["Mobile","New","Universal"],updated:"NOV 24, 2026",status:"NEW",access:"Keyless",link:DISCORD},
 {id:"universal-interface",name:"Universal Interface",game:"Universal",description:"A clean example interface layout with configurable tabs, controls, and theme settings.",tags:["Universal","Keyless"],updated:"NOV 22, 2026",status:"UPDATED",access:"Keyless",link:DISCORD},
 {id:"key-system-demo",name:"Key System Demo",game:"Demo project",description:"A demonstration entry showing how a key-gated access flow is labelled in the directory.",tags:["Key System","New"],updated:"NOV 21, 2026",status:"NEW",access:"Key System",link:DISCORD},
 {id:"touch-controls",name:"Touch Controls",game:"Universal",description:"A mobile-first control example with touch-friendly spacing and layout.",tags:["Mobile","Universal"],updated:"NOV 18, 2026",status:"AVAILABLE",access:"Keyless",link:DISCORD}
];
const scriptTags=["All","Mobile","PC","Key System","Keyless","New","Updated","Universal"];
let activeScriptTag="All";
function renderScriptDirectory(){
 const grid=document.getElementById("scriptGrid"); if(!grid)return;
 const terms=(document.getElementById("scriptSearch")?.value||"").trim().toLowerCase().split(/\s+/).filter(Boolean);
 const matches=scriptCatalog.filter(s=>{
  const searchable=[s.name,s.game,s.description,s.status,s.access,...s.tags].join(" ").toLowerCase();
  const tagMatch=activeScriptTag==="All" || s.tags.includes(activeScriptTag) || (activeScriptTag==="Updated"&&s.status==="UPDATED");
  return tagMatch && terms.every(term=>searchable.includes(term));
 });
 const count=document.getElementById("scriptResultCount"); if(count)count.textContent=`${matches.length} / ${scriptCatalog.length} SCRIPTS`;
 grid.innerHTML=matches.map(s=>`<article class="script-card"><div class="script-card-top"><span class="script-status ${s.status.toLowerCase()}">${s.status}</span><span class="script-updated">${s.updated}</span></div><div class="script-card-icon">⌘</div><div class="script-game">${escapeHTML(s.game)}</div><h3>${escapeHTML(s.name)}</h3><p>${escapeHTML(s.description)}</p><div class="script-tags">${s.tags.map(t=>`<span class="script-tag">${escapeHTML(t)}</span>`).join("")}</div><div class="script-card-bottom"><span>${escapeHTML(s.access)}</span><button class="script-view" data-script-id="${s.id}">View details ↗</button></div></article>`).join("");
 const empty=document.getElementById("scriptEmpty");if(empty)empty.hidden=matches.length>0;
}
function escapeHTML(v){return String(v).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function initScriptDirectory(){
 const input=document.getElementById("scriptSearch");if(!input)return;
 const filters=document.getElementById("tagFilters");
 filters.innerHTML=scriptTags.map(t=>`<button class="tag-filter ${t==="All"?"active":""}" data-script-tag="${t}">${t}</button>`).join("");
 input.addEventListener("input",renderScriptDirectory);
 filters.addEventListener("click",e=>{const b=e.target.closest("[data-script-tag]");if(!b)return;activeScriptTag=b.dataset.scriptTag;filters.querySelectorAll(".tag-filter").forEach(x=>x.classList.toggle("active",x===b));renderScriptDirectory();});
 document.getElementById("clearScriptFilters")?.addEventListener("click",()=>{input.value="";activeScriptTag="All";filters.querySelectorAll(".tag-filter").forEach(x=>x.classList.toggle("active",x.dataset.scriptTag==="All"));renderScriptDirectory();});
 const modal=document.getElementById("scriptModal");
 document.getElementById("scriptGrid").addEventListener("click",e=>{const b=e.target.closest("[data-script-id]");if(!b)return;const s=scriptCatalog.find(x=>x.id===b.dataset.scriptId);if(!s)return;
  document.getElementById("scriptModalCategory").textContent=`${s.game.toUpperCase()} / ${s.status}`;
  document.getElementById("scriptModalTitle").textContent=s.name;document.getElementById("scriptModalDescription").textContent=s.description;
  document.getElementById("scriptModalTags").innerHTML=s.tags.map(t=>`<span class="script-tag">${escapeHTML(t)}</span>`).join("");
  document.getElementById("scriptModalMeta").textContent=`Access: ${s.access}  •  Updated: ${s.updated}`;
  document.getElementById("scriptModalLink").href=s.link||DISCORD;modal.classList.add("show");modal.setAttribute("aria-hidden","false");document.body.classList.add("modal-open");
 });
 modal.querySelectorAll("[data-close-script]").forEach(el=>el.addEventListener("click",closeScriptModal));
 document.addEventListener("keydown",e=>{if(e.key==="Escape")closeScriptModal();});
}
function closeScriptModal(){const m=document.getElementById("scriptModal");if(m){m.classList.remove("show");m.setAttribute("aria-hidden","true");document.body.classList.remove("modal-open");}}
initScriptDirectory();renderScriptDirectory();

document.addEventListener("keydown",e=>{if(e.key==="Escape"){closeScriptModal();document.getElementById("musicPrompt")?.classList.remove("show");}});
document.getElementById("changelogList").innerHTML=changes.map(c=>`<article class="timeline-item reveal"><div><div class="timeline-version">VERSION ${c.version}</div><span class="timeline-date">${c.date}</span></div><div><h3>${c.title}</h3><p>${c.description}</p></div><span class="timeline-tag">${c.tag}</span></article>`).join("");
document.getElementById("faqList").innerHTML=faqs.map(([q,a])=>`<article class="faq-item"><button class="faq-question" aria-expanded="false"><span>${q}</span><span>＋</span></button><div class="faq-answer"><p>${a}</p></div></article>`).join("");
document.getElementById("faqList").addEventListener("click",e=>{
  const button=e.target.closest(".faq-question");if(!button)return;
  const item=button.parentElement,answer=item.querySelector(".faq-answer"),open=item.classList.toggle("open");
  button.setAttribute("aria-expanded",String(open));answer.style.maxHeight=open?answer.scrollHeight+"px":"0px";
});

const revealObserver=new IntersectionObserver(entries=>entries.forEach(entry=>{if(entry.isIntersecting){entry.target.classList.add("visible");revealObserver.unobserve(entry.target);}}),{threshold:.12});
function observeReveals(){document.querySelectorAll(".reveal:not(.visible)").forEach(el=>revealObserver.observe(el));}
observeReveals();
document.getElementById("year").textContent=new Date().getFullYear();

const menu=document.getElementById("menuToggle"),nav=document.getElementById("navLinks");
menu.addEventListener("click",()=>nav.classList.toggle("open"));
nav.querySelectorAll("a").forEach(a=>a.addEventListener("click",()=>nav.classList.remove("open")));
window.addEventListener("scroll",()=>{
  const max=document.documentElement.scrollHeight-innerHeight;
  document.getElementById("scrollProgress").style.width=(max>0?scrollY/max*100:0)+"%";
},{passive:true});

/* Soft synthesized ambient pad: no external audio file or autoplay. */
let audioCtx=null, master=null, oscillators=[], musicOn=false;
function startAmbient(){
  const AudioContext=window.AudioContext||window.webkitAudioContext;
  if(!AudioContext){showToast("Background audio is not supported in this browser.");return;}
  if(!audioCtx){
    audioCtx=new AudioContext();master=audioCtx.createGain();master.gain.value=0;master.connect(audioCtx.destination);
    [110,164.81,220].forEach((freq,i)=>{
      const osc=audioCtx.createOscillator(),gain=audioCtx.createGain(),filter=audioCtx.createBiquadFilter();
      osc.type=i===1?"triangle":"sine";osc.frequency.value=freq;gain.gain.value=[.12,.045,.035][i];filter.type="lowpass";filter.frequency.value=420;
      osc.connect(filter);filter.connect(gain);gain.connect(master);osc.start();oscillators.push(osc);
    });
  }
  audioCtx.resume();master.gain.cancelScheduledValues(audioCtx.currentTime);master.gain.setTargetAtTime(.18,audioCtx.currentTime,.8);musicOn=true;updateSoundButton();
}
function stopAmbient(){
  if(audioCtx&&master){master.gain.cancelScheduledValues(audioCtx.currentTime);master.gain.setTargetAtTime(0,audioCtx.currentTime,.35);}
  musicOn=false;updateSoundButton();
}
function updateSoundButton(){document.getElementById("soundToggle").textContent=musicOn?"♫":"♪";document.getElementById("soundToggle").title=musicOn?"Turn music off":"Turn music on";}
function showToast(msg){const t=document.getElementById("toast");t.textContent=msg;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2200);}
document.getElementById("musicYes").addEventListener("click",()=>{startAmbient();document.getElementById("musicPrompt").classList.remove("show");});
document.getElementById("musicNo").addEventListener("click",()=>{document.getElementById("musicPrompt").classList.remove("show");});
document.getElementById("soundToggle").addEventListener("click",()=>{if(musicOn)stopAmbient();else startAmbient();});
function finishLoading(){
  document.getElementById("loader")?.classList.add("done");
  observeReveals();
  try {
    if(!sessionStorage.getItem("shadywareMusicChoice")){
      document.getElementById("musicPrompt")?.classList.add("show");
      document.getElementById("musicYes")?.addEventListener("click",()=>sessionStorage.setItem("shadywareMusicChoice","yes"),{once:true});
      document.getElementById("musicNo")?.addEventListener("click",()=>sessionStorage.setItem("shadywareMusicChoice","no"),{once:true});
    }
  } catch (_) { /* Private browsing can block storage; the site still works. */ }
}
if(document.readyState==="complete") setTimeout(finishLoading,450);
else window.addEventListener("load",()=>setTimeout(finishLoading,450),{once:true});
setTimeout(finishLoading,3500);
