SHADYWARE WEBSITE — FULL BUILD

DEPLOY
1. Upload index.html, styles.css, script.js, README.txt, and the products folder to the ROOT of your GitHub repository.
2. In Render, use Static Site with the GitHub repository, branch main, Build Command blank, Publish Directory .
3. Every commit to main will redeploy if Auto-Deploy is enabled.

SITE CONTENT
- Home page, animated silver rain, responsive navigation, script directory search, tag filters, and detail popups
- Three separate product detail pages in /products/
- Changelog, team, creator program, FAQ, Discord links
- Optional synthesized ambient sound (only after a visitor clicks Turn it on)

EDIT SCRIPT DIRECTORY
Open script.js and edit the scriptCatalog array. Each entry supports id, name, game, description, tags, updated, status, access, and link. Use tags such as Mobile, PC, Key System, Keyless, New, and Updated. Search checks each word against the entry details and tags. Current entries are examples; replace them with real published entries and working links. The search filters this site's catalog; it does not crawl the internet or Roblox automatically.

PRODUCT DETAIL PAGES
The /products/ folder contains the sample detail pages. Update or replace these if you decide to use individual product pages alongside the script directory.

EDIT CHANGELOG / FAQ
Edit the changes and faqs arrays in script.js.

TEAM IMAGES
The supplied iBB links are included exactly as provided and are clickable. iBB share-page URLs may not work as direct image sources in browsers; if an image does not display, replace the img src with the direct image URL from iBB (usually an i.ibb.co URL). The fallback initials will display otherwise.

DISCORD
https://discord.gg/GSevFng2Ap


SCRIPT DIRECTORY
Edit the scriptCatalog array in script.js to add real entries. Each entry supports name, game, description, tags, updated, status, access, and link. Search checks all these fields. Tags include Mobile, PC, Key System, Keyless, New, Updated, and Universal. The current entries are demo placeholders; replace them with your own approved catalog entries and actual Discord/product links.
