SHADYWARE WEBSITE

Files:
- index.html: page structure and website content
- styles.css: visual design and responsive layout
- script.js: product cards, changelog entries, FAQ, and interactions

CUSTOMIZE:
1. Open script.js.
2. Edit the `products` array to rename products, add descriptions, and set status text.
3. Edit the `changelogs` array to add release versions and update notes.
4. Edit the `faqs` array to change questions and answers.
5. The Discord invite is currently set to https://discord.gg/GSevFng2Ap.

To add another product, copy one object inside the products array and change its fields.
To add a changelog, copy one object inside the changelogs array.

HOSTING:
Upload the contents of this folder to a static website host (for example, Netlify, Cloudflare Pages, or GitHub Pages). No build step or backend is required.
